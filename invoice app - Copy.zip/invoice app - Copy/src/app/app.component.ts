import { Component } from '@angular/core';

import pdfMake from "pdfmake/build/pdfmake";
//import pdfFonts from "pdfmake/build/vfs_fonts";

import pdfFonts from "../assets/vfs_fonts"
import { fonts } from './configs/pdfFonts';

pdfMake.vfs = pdfFonts.pdfMake.vfs;
pdfMake.fonts= fonts;
class Product{
  name: string;
  price: number;
  qty: number;
}
class Invoice{
  customerName: string;
  address: string;
  contactNo: number;
  email: string;
  
  products: Product[] = [];
  additionalDetails: string;

  constructor(){
    // Initially one empty product row we will show 
    this.products.push(new Product());
  }
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  invoice = new Invoice(); 

  
  
  generatePDF(action = 'open') {
    const currencyFormatter = (value) => {
      const formattedValue = value.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      return `${formattedValue}`;
    };

    let docDefinition = {
      pageSize: {
        width: 226.772,
        height: 'auto',
        
      },
      content: [
        
        {alignment: 'center',margin:[-40,-20,2,0],style:"fontsMontserrat",
          columns: [
            [ 
              {
                text: 'Federal Neuro-psychitric Hospital Sokoto',alignment: 'center',margin:[0,5,0,10]
              },
              {
                image:'logobw.png',
                width:44,
                height:44,
                margin:[0,0,0,5]
              },
              { 
              text: `Receipt No : A039820230526${((Math.random() *1890008).toFixed(0))}`,
              alignment: 'center',
              
              },
              { 
                text:"Name: "+this.invoice.customerName,
                alignment: 'center'
              },
              { text:"Patient No: "+ this.invoice.address,
                alignment: 'center'
              },
              { text:"Agent Name: "+ this.invoice.email,
                alignment: 'center',
              },
              { text: "CUSTOMER COPY",
                alignment: 'center',
              },
              {
                text: "DEPARTMENT: BED SPACE",
                alignment: 'center',margin: [0, 0, 0, 20]
              },
              {
                table: {
                  widths: [130, 70],
                  body: [
                    [{text:'Service',margin: [32, 0, 0, 0],border:[false,false,false,false]},{text:'Price', alignment:'right',border:[false,false,false,false]}],
                    ...this.invoice.products.map(p => ([{text:p.name,noWrap:true,alignment:'center',fit:false,margin: [125, 0, 0, 0],border:[false,false,false,false]},{text:currencyFormatter(p.price),alignment:'right',border:[false,false,false,false]}])),
      
                    [{text: 'TOTAL',border:[false,true,false,true],margin: [30, 5, 0, 2]}, {text:"NGN"+currencyFormatter(this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0)),border:[false,false,false,false],margin: [-5, 5, 0, 5]}],
                    [{text:'',border:[false,true,false,true]},{text:'',border:[false,false,false,false]}]
                    // [{text: 'Total Amount', colSpan: 1}, this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0).toFixed(2)]
                  ]  
                },alignment: 'center',layout:{
                  
                    hLineStyle: function (i, node) {
                      //return {dash: {length: 10, space: 0},};
                    },
                    hLineColor: function (i, node) {
                      return (i === 1||i === 0 || i === node.table.body.length) ? 'gray' : 'gray';
                   },paddingTop:function(i,node){
                    return -1;
                   }}
                     
              },
              {
                 text: 'Thank you!',
                 alignment: 'center',
                 margin: [0, 15,0, 0],  
              },
              {
                text: `${new Date().toLocaleString()}`,
                alignment: 'center',
              },
              { text: 'Powered by Revonue',
                alignment: 'center',margin:[0,0,0,5],
              },
              //////////////////////////////////////////////////////1
              {
                text: 'Federal Neuro-psychitric Hospital Sokoto',alignment: 'center',margin:[0,5,0,10]
              },
              {
                image:'logobw.png',
                width:44,
                height:44,
                margin:[0,0,0,5]
              },
              { 
              text: `Receipt No : A039820230526${((Math.random() *1890008).toFixed(0))}`,
              alignment: 'center',
              
              },
              { 
                text:"Name: "+this.invoice.customerName,
                alignment: 'center'
              },
              { text:"Patient No: "+ this.invoice.address,
                alignment: 'center'
              },
              { text:"Agent Name: "+ this.invoice.email,
                alignment: 'center',
              },
              { text: "CUSTOMER COPY",
                alignment: 'center',
              },
              {
                text: "DEPARTMENT: FEEDING",
                alignment: 'center',margin: [0, 0, 0, 20]
              },
              {
                table: {
                  widths: [130, 70],
                  body: [
                    [{text:'Service',margin: [32, 0, 0, 0],border:[false,false,false,false]},{text:'Price', alignment:'right',border:[false,false,false,false]}],
                    ...this.invoice.products.map(p => ([{text:p.name,noWrap:true,alignment:'center',fit:false,margin: [125, 0, 0, 0],border:[false,false,false,false]},{text:currencyFormatter(p.price),alignment:'right',border:[false,false,false,false]}])),
      
                    [{text: 'TOTAL',border:[false,true,false,true],margin: [30, 5, 0, 2]}, {text:"NGN"+currencyFormatter(this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0)),border:[false,false,false,false],margin: [-5, 5, 0, 5]}],
                    [{text:'',border:[false,true,false,true]},{text:'',border:[false,false,false,false]}]
                    // [{text: 'Total Amount', colSpan: 1}, this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0).toFixed(2)]
                  ]  
                },alignment: 'center',layout:{
                  
                    hLineStyle: function (i, node) {
                      //return {dash: {length: 10, space: 0},};
                    },
                    hLineColor: function (i, node) {
                      return (i === 1||i === 0 || i === node.table.body.length) ? 'gray' : 'gray';
                   },paddingTop:function(i,node){
                    return -1;
                   }}
                     
              },
              {
                 text: 'Thank you!',
                 alignment: 'center',
                 margin: [0, 15,0, 0],  
              },
              {
                text: `${new Date().toLocaleString()}`,
                alignment: 'center',
              },
              { text: 'Powered by Revonue',
                alignment: 'center',margin:[0,0,0,20],
              },
              /////////////////////////////////////////////////////2
              {
                text: 'Federal Neuro-psychitric Hospital Sokoto',alignment: 'center',margin:[0,5,0,10]
              },
              {
                image:'logobw.png',
                width:44,
                height:44,
                margin:[0,0,0,5]
              },
              { 
              text: `Receipt No : A039820230526${((Math.random() *1890008).toFixed(0))}`,
              alignment: 'center',
              
              },
              { 
                text:"Name: "+this.invoice.customerName,
                alignment: 'center'
              },
              { text:"Patient No: "+ this.invoice.address,
                alignment: 'center'
              },
              { text:"Agent Name: "+ this.invoice.email,
                alignment: 'center',
              },
              { text: "CUSTOMER COPY",
                alignment: 'center',
              },
              {
                text: "DEPARTMENT: DRUGS",
                alignment: 'center',margin: [0, 0, 0, 20]
              },
              {
                table: {
                  widths: [130, 70],
                  body: [
                    [{text:'Service',margin: [32, 0, 0, 0],border:[false,false,false,false]},{text:'Price', alignment:'right',border:[false,false,false,false]}],
                    ...this.invoice.products.map(p => ([{text:p.name,noWrap:true,alignment:'center',fit:false,margin: [125, 0, 0, 0],border:[false,false,false,false]},{text:currencyFormatter(p.price),alignment:'right',border:[false,false,false,false]}])),
      
                    [{text: 'TOTAL',border:[false,true,false,true],margin: [30, 5, 0, 2]}, {text:"NGN"+currencyFormatter(this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0)),border:[false,false,false,false],margin: [-5, 5, 0, 5]}],
                    [{text:'',border:[false,true,false,true]},{text:'',border:[false,false,false,false]}]
                    // [{text: 'Total Amount', colSpan: 1}, this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0).toFixed(2)]
                  ]  
                },alignment: 'center',layout:{
                  
                    hLineStyle: function (i, node) {
                      //return {dash: {length: 10, space: 0},};
                    },
                    hLineColor: function (i, node) {
                      return (i === 1||i === 0 || i === node.table.body.length) ? 'gray' : 'gray';
                   },paddingTop:function(i,node){
                    return -1;
                   }}
                     
              },
              {
                 text: 'Thank you!',
                 alignment: 'center',
                 margin: [0, 15,0, 0],  
              },
              {
                text: `${new Date().toLocaleString()}`,
                alignment: 'center',
              },
              { text: 'Powered by Revonue',
                alignment: 'center',margin:[0,0,0,20],
              },
              ////////////////////////////////////////////////////3
              {
                text: 'Federal Neuro-psychitric Hospital Sokoto',alignment: 'center',margin:[0,5,0,10]
              },
              {
                image:'logobw.png',
                width:44,
                height:44,
                margin:[0,0,0,5]
              },
              { 
              text: `Receipt No : A039820230526${((Math.random() *1890008).toFixed(0))}`,
              alignment: 'center',
              
              },
              { 
                text:"Name: "+this.invoice.customerName,
                alignment: 'center'
              },
              { text:"Patient No: "+ this.invoice.address,
                alignment: 'center'
              },
              { text:"Agent Name: "+ this.invoice.email,
                alignment: 'center',
              },
              { text: "CUSTOMER COPY",
                alignment: 'center',
              },
              {
                text: "DEPARTMENT: UTILITY AND UNIFORM",
                alignment: 'center',margin: [0, 0, 0, 20]
              },
              {
                table: {
                  widths: [130, 70],
                  body: [
                    [{text:'Service',margin: [32, 0, 0, 0],border:[false,false,false,false]},{text:'Price', alignment:'right',border:[false,false,false,false]}],
                    ...this.invoice.products.map(p => ([{text:p.name,noWrap:true,alignment:'center',fit:false,margin: [125, 0, 0, 0],border:[false,false,false,false]},{text:currencyFormatter(p.price),alignment:'right',border:[false,false,false,false]}])),
      
                    [{text: 'TOTAL',border:[false,true,false,true],margin: [30, 5, 0, 2]}, {text:"NGN"+currencyFormatter(this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0)),border:[false,false,false,false],margin: [-5, 5, 0, 5]}],
                    [{text:'',border:[false,true,false,true]},{text:'',border:[false,false,false,false]}]
                    // [{text: 'Total Amount', colSpan: 1}, this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0).toFixed(2)]
                  ]  
                },alignment: 'center',layout:{
                  
                    hLineStyle: function (i, node) {
                      //return {dash: {length: 10, space: 0},};
                    },
                    hLineColor: function (i, node) {
                      return (i === 1||i === 0 || i === node.table.body.length) ? 'gray' : 'gray';
                   },paddingTop:function(i,node){
                    return -1;
                   }}
                     
              },
              {
                 text: 'Thank you!',
                 alignment: 'center',
                 margin: [0, 15,0, 0],  
              },
              {
                text: `${new Date().toLocaleString()}`,
                alignment: 'center',
              },
              { text: 'Powered by Revonue',
                alignment: 'center',margin:[0,0,0,20],
              },
              ////////////////////////////////////////////////////////
              {
                text: 'Federal Neuro-psychitric Hospital Sokoto',alignment: 'center',margin:[0,10,0,10]
              },
              {
                image:'logobw.png',
                width:44,
                height:44,
                margin:[0,0,0,5]
              },
              { 
              text: `Receipt No : A039820230526${((Math.random() *1890008).toFixed(0))}`,
              alignment: 'center',
              
              },
              { 
                text:"Name: "+this.invoice.customerName,
                alignment: 'center'
              },
              { text:"Patient No: "+ this.invoice.address,
                alignment: 'center'
              },
              { text:"Agent Name: "+ this.invoice.email,
                alignment: 'center',
              },
              { text: "CUSTOMER COPY",
                alignment: 'center',
              },
              {
                text: "DEPARTMENT: PSYCOLOGY",
                alignment: 'center',margin: [0, 0, 0, 20]
              },
              {
                table: {
                  widths: [130, 70],
                  body: [
                    [{text:'Service',margin: [32, 0, 0, 0],border:[false,false,false,false]},{text:'Price', alignment:'right',border:[false,false,false,false]}],
                    ...this.invoice.products.map(p => ([{text:p.name,noWrap:true,alignment:'center',fit:false,margin: [125, 0, 0, 0],border:[false,false,false,false]},{text:currencyFormatter(p.price),alignment:'right',border:[false,false,false,false]}])),
      
                    [{text: 'TOTAL',border:[false,true,false,true],margin: [30, 5, 0, 2]}, {text:"NGN"+currencyFormatter(this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0)),border:[false,false,false,false],margin: [-5, 5, 0, 5]}],
                    [{text:'',border:[false,true,false,true]},{text:'',border:[false,false,false,false]}]
                    // [{text: 'Total Amount', colSpan: 1}, this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0).toFixed(2)]
                  ]  
                },alignment: 'center',layout:{
                  
                    hLineStyle: function (i, node) {
                      //return {dash: {length: 10, space: 0},};
                    },
                    hLineColor: function (i, node) {
                      return (i === 1||i === 0 || i === node.table.body.length) ? 'gray' : 'gray';
                   },paddingTop:function(i,node){
                    return -1;
                   }}
                     
              },
              {
                 text: 'Thank you!',
                 alignment: 'center',
                 margin: [0, 15,0, 0],  
              },
              {
                text: `${new Date().toLocaleString()}`,
                alignment: 'center',
              },
              { text: 'Powered by Revonue',
                alignment: 'center',margin:[0,0,0,20],
              },
              //////////////////////////////////////////////////////////
              {
                text: 'Federal Neuro-psychitric Hospital Sokoto',alignment: 'center',margin:[0,10,0,10]
              },
              {
                image:'logobw.png',
                width:44,
                height:44,
                margin:[0,0,0,5]
              },
              { 
              text: `Receipt No : A039820230526${((Math.random() *1890008).toFixed(0))}`,
              alignment: 'center',
              
              },
              { 
                text:"Name: "+this.invoice.customerName,
                alignment: 'center'
              },
              { text:"Patient No: "+ this.invoice.address,
                alignment: 'center'
              },
              { text:"Agent Name: "+ this.invoice.email,
                alignment: 'center',
              },
              { text: "CUSTOMER COPY",
                alignment: 'center',
              },
              {
                text: "DEPARTMENT: LABORATORY",
                alignment: 'center',margin: [0, 0, 0, 20]
              },
              {
                table: {
                  widths: [130, 70],
                  body: [
                    [{text:'Service',margin: [32, 0, 0, 0],border:[false,false,false,false]},{text:'Price', alignment:'right',border:[false,false,false,false]}],
                    ...this.invoice.products.map(p => ([{text:p.name,noWrap:true,alignment:'center',fit:false,margin: [125, 0, 0, 0],border:[false,false,false,false]},{text:currencyFormatter(p.price),alignment:'right',border:[false,false,false,false]}])),
      
                    [{text: 'TOTAL',border:[false,true,false,true],margin: [30, 5, 0, 2]}, {text:"NGN"+currencyFormatter(this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0)),border:[false,false,false,false],margin: [-5, 5, 0, 5]}],
                    [{text:'',border:[false,true,false,true]},{text:'',border:[false,false,false,false]}]
                    // [{text: 'Total Amount', colSpan: 1}, this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0).toFixed(2)]
                  ]  
                },alignment: 'center',layout:{
                  
                    hLineStyle: function (i, node) {
                      //return {dash: {length: 10, space: 0},};
                    },
                    hLineColor: function (i, node) {
                      return (i === 1||i === 0 || i === node.table.body.length) ? 'gray' : 'gray';
                   },paddingTop:function(i,node){
                    return -1;
                   }}
                     
              },
              {
                 text: 'Thank you!',
                 alignment: 'center',
                 margin: [0, 15,0, 0],  
              },
              {
                text: `${new Date().toLocaleString()}`,
                alignment: 'center',
              },
              { text: 'Powered by Revonue',
                alignment: 'center',margin:[0,0,0,20],
              },
              ///////////////////////////////////////////////////////
              {
                text: 'Federal Neuro-psychitric Hospital Sokoto',alignment: 'center',margin:[0,10,0,10]
              },
              {
                image:'logobw.png',
                width:44,
                height:44,
                margin:[0,0,0,5]
              },
              { 
              text: `Receipt No : A039820230526${((Math.random() *1890008).toFixed(0))}`,
              alignment: 'center',
              
              },
              { 
                text:"Name: "+this.invoice.customerName,
                alignment: 'center'
              },
              { text:"Patient No: "+ this.invoice.address,
                alignment: 'center'
              },
              { text:"Agent Name: "+ this.invoice.email,
                alignment: 'center',
              },
              { text: "CUSTOMER COPY",
                alignment: 'center',
              },
              {
                text: "DEPARTMENT: OCCUPATIONAL THERAPY",
                alignment: 'center',margin: [0, 0, 0, 20]
              },
              {
                table: {
                  widths: [130, 70],
                  body: [
                    [{text:'Service',margin: [32, 0, 0, 0],border:[false,false,false,false]},{text:'Price', alignment:'right',border:[false,false,false,false]}],
                    ...this.invoice.products.map(p => ([{text:p.name,noWrap:true,alignment:'center',fit:false,margin: [125, 0, 0, 0],border:[false,false,false,false]},{text:currencyFormatter(p.price),alignment:'right',border:[false,false,false,false]}])),
      
                    [{text: 'TOTAL',border:[false,true,false,true],margin: [30, 5, 0, 2]}, {text:"NGN"+currencyFormatter(this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0)),border:[false,false,false,false],margin: [-5, 5, 0, 5]}],
                    [{text:'',border:[false,true,false,true]},{text:'',border:[false,false,false,false]}]
                    // [{text: 'Total Amount', colSpan: 1}, this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0).toFixed(2)]
                  ]  
                },alignment: 'center',layout:{
                  
                    hLineStyle: function (i, node) {
                      //return {dash: {length: 10, space: 0},};
                    },
                    hLineColor: function (i, node) {
                      return (i === 1||i === 0 || i === node.table.body.length) ? 'gray' : 'gray';
                   },paddingTop:function(i,node){
                    return -1;
                   }}
                     
              },
              {
                 text: 'Thank you!',
                 alignment: 'center',
                 margin: [0, 15,0, 0],  
              },
              {
                text: `${new Date().toLocaleString()}`,
                alignment: 'center',
              },
              { text: 'Powered by Revonue',
                alignment: 'center',margin:[0,0,0,20],
              },
              //////////////////////////////////////////////////////////
              {
                text: "Federal Neuro-Psychitric Hospital Sokoto",alignment: 'center',margin:[0,10,0,10]
              },
              {
                image:'logobw.png',
                width:44,
                height:44,
                margin:[0,0,0,5]
              },
              { 
              text: `Receipt No : A039820230526${((Math.random() *1890008).toFixed(0))}`,
              alignment: 'center',
              
              },
              { 
                text:"Name: "+this.invoice.customerName,
                alignment: 'center'
              },
              { text:"Patient No: "+ this.invoice.address,
                alignment: 'center'
              },
              { text:"Agent Name: "+ this.invoice.email,
                alignment: 'center',
              },
              { text: "CUSTOMER COPY",
                alignment: 'center',
              },
              {
                text: "DEPARTMENT: FED. NEURO PSYCHIATRIC HOSPITAL FEE     S",
                alignment: 'center',margin: [0, 0, 0, 20],fontSize:8,
              },
              {
                table: {
                  widths: [130, 70],
                  body: [
                    [{text:'Service',margin: [32, 0, 0, 0],border:[false,false,false,false]},{text:'Price', alignment:'right',border:[false,false,false,false]}],
                    ...this.invoice.products.map(p => ([{text:p.name,noWrap:true,alignment:'center',fit:false,margin: [125, 0, 0, 0],border:[false,false,false,false]},{text:currencyFormatter(p.price),alignment:'right',border:[false,false,false,false]}])),
      
                    [{text: 'TOTAL',border:[false,true,false,true],margin: [30, 5, 0, 2]}, {text:"NGN"+currencyFormatter(this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0)),border:[false,false,false,false],margin: [-5, 5, 0, 5]}],
                    [{text:'',border:[false,true,false,true]},{text:'',border:[false,false,false,false]}]
                    // [{text: 'Total Amount', colSpan: 1}, this.invoice.products.reduce((sum, p)=> sum + (p.qty * p.price), 0).toFixed(2)]
                  ]  
                },alignment: 'center',layout:{
                  
                    hLineStyle: function (i, node) {
                      //return {dash: {length: 10, space: 0},};
                    },
                    hLineColor: function (i, node) {
                      return (i === 1||i === 0 || i === node.table.body.length) ? 'gray' : 'gray';
                   },paddingTop:function(i,node){
                    return -1;
                   }}
                     
              },
              {
                 text: 'Thank you!',
                 alignment: 'center',
                 margin: [0, 15,0, 0],  
              },
              {
                text: `${new Date().toLocaleString()}`,
                alignment: 'center',
              },
              { text: 'Powered by Revonue',
                alignment: 'center',margin:[0,0,0,20],
              },
              ///////////////////////////////////////////////////

            
            ],
            
          ],
          
        },
        
       

      ],
      styles: {
        fontsMontserrat:{
          font:'UKIJTuz',
          fontSize:10,
          normal:true,
        },
        receip: {
          font:'MaterialIcons',
          bold:true,
          color:"#000",
          fontSize:10,        
        },
        defaultStyle: {
          font:'Montserrat',
          
      }

      }
    };

   
   
    if(action==='download'){
      pdfMake.createPdf(docDefinition).download();
    }else if(action === 'print'){
      pdfMake.createPdf(docDefinition).print();      
    }else{
      pdfMake.createPdf(docDefinition,).open();      
    }

  }

  addProduct(){
    this.invoice.products.push(new Product());
  }

  
  
}
