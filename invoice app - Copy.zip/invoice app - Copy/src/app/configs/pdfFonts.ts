export const fonts = {

    Montserrat:{
        bold:"Montserrat-Bold.ttf",
        normal:"Montserrat-Light.ttf",
        italics:"Montserrat-Medium.ttf"
    },

    MaterialIcons:{
        normal:"MaterialIcons-Regular.otf"
    },
    Roboto: {
        normal: 'Montserrat-Medium.ttf',
        bold: 'Roboto-Medium.ttf',
        italics: 'Roboto-Italic.ttf',
        bolditalics: 'Roboto-Italic.ttf'
    },

    decterm:{
        normal:"decterm.ttf",
    },

    NotCourierSans:{
        normal:"NotCourierSans.ttf",
    },
    UKIJTuz:{
        normal:"UKIJTuz.ttf",
    }



    
    


}